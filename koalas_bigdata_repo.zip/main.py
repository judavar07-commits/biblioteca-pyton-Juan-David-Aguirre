import databricks.koalas as ks
import numpy as np
import matplotlib.pyplot as plt

# Simulación de un dataset grande
n = 10**6
kdf = ks.DataFrame({
    'id': np.arange(n),
    'categoria': np.random.choice(['A','B','C','D'], size=n),
    'valor': np.random.randn(n)*100,
    'ventas': np.random.randint(1, 500, size=n)
})

# Mostrar información inicial
print("Primeras filas del DataFrame:")
print(kdf.head())

# Estadísticas básicas
print("\nDescripción estadística de la columna valor:")
print(kdf['valor'].describe())

# Agrupación por categoría
print("\nPromedio de valor por categoría:")
print(kdf.groupby('categoria')['valor'].mean())

# Suma de ventas por categoría
ventas_por_categoria = kdf.groupby('categoria')['ventas'].sum().to_pandas()
print("\nVentas totales por categoría:")
print(ventas_por_categoria)

# Exportar resultados a CSV
ventas_por_categoria.to_csv("ventas_categoria.csv")
print("\nArchivo ventas_categoria.csv generado con éxito.")

# Graficar resultados
ventas_por_categoria.plot(kind='bar', title="Ventas totales por categoría")
plt.xlabel("Categoría")
plt.ylabel("Ventas")
plt.savefig("grafico_ventas.png")
print("Gráfico guardado como grafico_ventas.png")
